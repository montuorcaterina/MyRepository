document.addEventListener("DOMContentLoaded", () => {
    const taskInput = document.getElementById("taskInput");
    const todoList = document.getElementById("todoList");
    const doneList = document.getElementById("doneList");
    const scoreDisplay = document.getElementById("score");
    
    let score = 0;
    let taskCount = 0; // Variabile per tenere traccia del numero delle task

    // Carica il punteggio e controlla se � necessario azzerarlo
    function loadScore() {
        const savedScore = localStorage.getItem("score");
        const lastReset = localStorage.getItem("lastReset");
        const today = new Date().toDateString();

        if (lastReset !== today) {
            score = 0;
            localStorage.setItem("score", score);
            localStorage.setItem("lastReset", today);
        } else {
            score = savedScore ? parseInt(savedScore) : 0;
        }
        updateScore();
    }

    function updateScore() {
        scoreDisplay.textContent = score;
        localStorage.setItem("score", score);
    }

    taskInput.addEventListener("keypress", (event) => {
        if (event.key === "Enter" && taskInput.value.trim() !== "") {
            addTask(taskInput.value.trim());
            taskInput.value = ""; // Resetta il campo input
        }
    });

    function addTask(taskText) {
        taskCount++; // Incrementa il contatore delle task
        const taskItem = document.createElement("li");
        taskItem.textContent = `${taskCount}. ${taskText}`; // Aggiungi la numerazione
        taskItem.addEventListener("click", () => completeTask(taskItem));
        todoList.appendChild(taskItem);
    }

    function completeTask(taskItem) {
        // Aggiungi la classe per la sbarratura
        taskItem.style.textDecoration = "line-through"; // Sbarrato
        taskItem.style.color = "#888"; // Colore grigio per il testo sbarrato

        // Rimuove l'evento di click
        taskItem.removeEventListener("click", () => completeTask(taskItem));

        // Sposta la task nella sezione "Done"
        doneList.appendChild(taskItem);

        score++;
        updateScore();
    }

    loadScore();
});


  META-INF/manifest.xmlPK         {    